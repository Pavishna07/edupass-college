
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { useNavigate, Link } from 'react-router-dom';
import { LogOut, Home, Users, CheckCircle, Bell } from 'lucide-react';
import { UserRole } from '../types';
import { db } from '../services/mockDb';

const Navbar: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user) {
      const interval = setInterval(() => {
        const notifs = db.getNotifications(user.uid);
        setUnreadCount(notifs.filter(n => !n.read).length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [user]);

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-indigo-600 text-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-xl font-bold tracking-tight italic">EduPass</Link>
            <div className="hidden md:flex space-x-4">
              <Link to="/" className="flex items-center space-x-1 hover:text-indigo-200 transition">
                <Home size={18} />
                <span className="text-xs font-black uppercase tracking-widest">Dashboard</span>
              </Link>
              {(user.role === UserRole.ADVISOR || user.role === UserRole.HOD) && (
                <Link to="/classroom" className="flex items-center space-x-1 hover:text-indigo-200 transition">
                  <Users size={18} />
                  <span className="text-xs font-black uppercase tracking-widest">{user.role === UserRole.ADVISOR ? 'My Classroom' : 'Department'}</span>
                </Link>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            {unreadCount > 0 && (user.role === UserRole.ADVISOR || user.role === UserRole.HOD) && (
              <div className="relative animate-bounce">
                <Bell size={20} className="text-white" />
                <span className="absolute -top-1 -right-1 bg-red-500 text-[8px] font-black px-1.5 py-0.5 rounded-full border-2 border-indigo-600">
                  {unreadCount}
                </span>
              </div>
            )}
            
            <div className="text-right hidden sm:block">
              <p className="text-sm font-black uppercase tracking-tight leading-none">{user.displayName}</p>
              <p className="text-[9px] text-indigo-200 font-black uppercase tracking-[0.2em] mt-1">{user.role.replace('_', ' ')}</p>
            </div>
            {user.profilePhoto && (
              <div className="w-10 h-10 rounded-xl border-2 border-indigo-400 overflow-hidden shadow-lg">
                <img src={user.profilePhoto} className="w-full h-full object-cover" alt="Profile" />
              </div>
            )}
            <button 
              onClick={handleLogout}
              className="p-2.5 rounded-xl hover:bg-white/10 transition active:scale-90"
              title="Logout"
            >
              <LogOut size={22} />
            </button>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
