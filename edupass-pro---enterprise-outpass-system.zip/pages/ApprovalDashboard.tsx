
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { db } from '../services/mockDb';
import { OutpassRequest, RequestStatus, UserRole, User, Notification } from '../types';
import { Check, X, User as UserIcon, Calendar, Clock, MapPin, Search, GraduationCap, History, Users, Plus, ShieldCheck, Bell } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const ApprovalDashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [pendingRequests, setPendingRequests] = useState<OutpassRequest[]>([]);
  const [history, setHistory] = useState<OutpassRequest[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showToast, setShowToast] = useState(false);

  useEffect(() => {
    if (!user) return;
    refreshData();
  }, [user]);

  const refreshData = () => {
    if (!user) return;
    const allRequests = db.getRequests();
    
    const pending = allRequests.filter(req => {
      // Security specifically looks for APPROVED (Warden level) requests
      if (user.role === UserRole.SECURITY) {
        return req.status === RequestStatus.APPROVED;
      }

      // Filter out completed or rejected items
      if (req.status === RequestStatus.REJECTED || req.status === RequestStatus.EXITED) return false;
      
      // Routing check: Ensure the request is at the correct authority level
      if (req.currentLevel !== user.role) return false;

      // Assignment filtering
      if (user.role === UserRole.ADVISOR) return req.advisorId === user.uid;
      if (user.role === UserRole.HOD) return req.hodId === user.uid;
      if (user.role === UserRole.DEPUTY_WARDEN) return req.deputyWardenId === user.uid;
      if (user.role === UserRole.WARDEN) return req.wardenId === user.uid;
      
      // Principal sees all departmental requests reaching their level
      return true;
    });

    const historyData = allRequests.filter(req => {
      if (user.role === UserRole.PRINCIPAL || user.role === UserRole.SECURITY) return true;
      if (user.role === UserRole.WARDEN) return req.wardenId === user.uid;
      if (user.role === UserRole.DEPUTY_WARDEN) return req.deputyWardenId === user.uid;
      if (user.role === UserRole.HOD) return req.hodId === user.uid;
      if (user.role === UserRole.ADVISOR) return req.advisorId === user.uid;
      return false;
    });

    setPendingRequests(pending);
    setHistory(historyData.sort((a, b) => b.createdAt - a.createdAt));
  };

  const handleAction = (reqId: string, action: 'approve' | 'reject' | 'exit') => {
    const nextStatusMap: Record<UserRole, RequestStatus> = {
      [UserRole.ADVISOR]: RequestStatus.HOD_PENDING,
      [UserRole.HOD]: RequestStatus.PRINCIPAL_PENDING,
      [UserRole.PRINCIPAL]: RequestStatus.DEPUTY_WARDEN_PENDING,
      [UserRole.DEPUTY_WARDEN]: RequestStatus.WARDEN_PENDING,
      [UserRole.WARDEN]: RequestStatus.APPROVED,
      [UserRole.SECURITY]: RequestStatus.EXITED,
      [UserRole.STUDENT]: RequestStatus.PENDING,
      [UserRole.ADMIN]: RequestStatus.APPROVED
    };

    const nextLevelMap: Record<UserRole, UserRole> = {
      [UserRole.ADVISOR]: UserRole.HOD,
      [UserRole.HOD]: UserRole.PRINCIPAL,
      [UserRole.PRINCIPAL]: UserRole.DEPUTY_WARDEN,
      [UserRole.DEPUTY_WARDEN]: UserRole.WARDEN,
      [UserRole.WARDEN]: UserRole.SECURITY,
      [UserRole.SECURITY]: UserRole.SECURITY,
      [UserRole.STUDENT]: UserRole.ADVISOR,
      [UserRole.ADMIN]: UserRole.ADMIN
    };

    if (action === 'approve') {
      db.updateRequest(reqId, { 
        status: nextStatusMap[user!.role],
        currentLevel: nextLevelMap[user!.role]
      });
    } else if (action === 'reject') {
      db.updateRequest(reqId, { status: RequestStatus.REJECTED });
    } else if (action === 'exit') {
      const req = db.getRequests().find(r => r.id === reqId);
      if (req) {
        db.updateRequest(reqId, { 
          status: RequestStatus.EXITED,
          exitVerifiedAt: Date.now()
        });

        if (req.advisorId) {
          const notification: Notification = {
            id: `notif-${Date.now()}`,
            userId: req.advisorId,
            title: 'Exit Verified',
            message: `Student ${req.studentName} (${req.studentRegNo}) has left the campus.`,
            timestamp: Date.now(),
            read: false,
            type: 'exit_verified'
          };
          db.addNotification(notification);
        }
        
        setShowToast(true);
        setTimeout(() => setShowToast(false), 3000);
      }
    }

    refreshData();
  };

  const filteredHistory = history.filter(r => 
    r.studentName.toLowerCase().includes(searchTerm.toLowerCase()) || 
    r.studentRegNo.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8 space-y-8 animate-in fade-in duration-700">
      {showToast && (
        <div className="fixed top-20 right-4 z-[100] bg-green-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-in slide-in-from-right duration-300">
          <ShieldCheck size={24} />
          <div>
            <p className="font-black uppercase text-xs tracking-widest">Exit Verified</p>
            <p className="text-[10px] font-bold opacity-90">Advisor notified successfully.</p>
          </div>
        </div>
      )}

      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-800 tracking-tight uppercase italic leading-none">Approval Center</h1>
          <p className="text-indigo-600 font-black uppercase tracking-widest text-xs mt-3 italic">
            STATUS: {user?.role.replace('_', ' ')} PORTAL ACTIVE
          </p>
        </div>
        
        {user?.role === UserRole.ADVISOR && (
          <button 
            onClick={() => navigate('/classroom')}
            className="group flex items-center gap-3 bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition active:scale-95"
          >
            <Users size={18} />
            Manage My Classrooms
          </button>
        )}
      </div>

      {user?.role === UserRole.ADVISOR && (
        <section className="bg-indigo-50 border-2 border-indigo-100 rounded-[2rem] p-8">
          <div className="flex items-center gap-3 mb-6">
            <Bell className="text-indigo-600" size={20} />
            <h2 className="text-xs font-black text-indigo-900 uppercase tracking-[0.2em]">Recent Identity Alerts</h2>
          </div>
          <div className="space-y-4">
            {db.getNotifications(user.uid).slice(0, 3).map(n => (
              <div key={n.id} className="bg-white border-2 border-slate-50 p-5 rounded-2xl flex justify-between items-center shadow-sm">
                <div className="flex items-center gap-4">
                  <div className="w-2.5 h-2.5 bg-green-500 rounded-full animate-pulse shadow-sm shadow-green-200"></div>
                  <p className="text-xs font-black text-slate-700 uppercase tracking-tight">{n.message}</p>
                </div>
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{new Date(n.timestamp).toLocaleTimeString()}</span>
              </div>
            ))}
            {db.getNotifications(user.uid).length === 0 && (
              <p className="text-xs font-bold text-indigo-300 italic opacity-60">System quiet. No new activity alerts.</p>
            )}
          </div>
        </section>
      )}

      {user?.role !== UserRole.SECURITY && (
        <section>
          <div className="flex items-center gap-3 mb-8">
            <Clock className="text-amber-500" size={24} />
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">
              Awaiting Signature <span className="text-indigo-600 ml-1">({pendingRequests.length})</span>
            </h2>
          </div>
          
          {pendingRequests.length === 0 ? (
            <div className="bg-white border-4 border-dashed border-slate-100 rounded-[3rem] p-24 text-center shadow-inner">
              <Clock className="mx-auto text-slate-100 mb-8" size={80} />
              <p className="text-slate-300 font-black text-2xl uppercase tracking-widest">Queue Clear</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {pendingRequests.map(req => (
                <div key={req.id} className="bg-white rounded-[2.5rem] p-8 shadow-2xl border-2 border-slate-50 flex flex-col justify-between hover:border-indigo-400 transition-all duration-500 group">
                  <div>
                    <div className="flex justify-between items-start mb-8">
                      <div className="flex items-center gap-5">
                        <div className="bg-indigo-600 p-4 rounded-2xl text-white shadow-lg shadow-indigo-100 group-hover:rotate-12 transition-transform">
                          <UserIcon size={28} />
                        </div>
                        <div>
                          <p className="font-black text-slate-900 text-2xl leading-none uppercase tracking-tight mb-2">{req.studentName}</p>
                          <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] italic">{req.studentRegNo}</p>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-8">
                      <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">GPA</p>
                        <p className="text-xl font-black text-indigo-600">{req.cgpa}</p>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Stay</p>
                        <p className="text-xl font-black text-slate-800">{req.stayDuration}</p>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-2xl text-center border border-slate-100">
                        <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-2">Past</p>
                        <p className="text-xl font-black text-amber-600">{req.previousLeaveCount}</p>
                      </div>
                    </div>

                    <div className="bg-indigo-50/50 p-6 rounded-3xl border-l-[6px] border-indigo-500 mb-8">
                      <p className="text-slate-700 font-black text-sm uppercase leading-relaxed italic">"{req.reason}"</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-4">
                    <button
                      onClick={() => handleAction(req.id, 'reject')}
                      className="flex-1 flex items-center justify-center gap-2 border-2 border-red-100 text-red-500 font-black py-5 rounded-2xl hover:bg-red-50 transition active:scale-95 uppercase tracking-[0.2em] text-[10px]"
                    >
                      <X size={20} /> REJECT
                    </button>
                    <button
                      onClick={() => handleAction(req.id, 'approve')}
                      className="flex-1 flex items-center justify-center gap-2 bg-indigo-600 text-white font-black py-5 rounded-2xl hover:bg-indigo-700 shadow-2xl shadow-indigo-200 transition active:scale-95 uppercase tracking-[0.2em] text-[10px]"
                    >
                      <Check size={20} /> APPROVE
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      )}

      {user?.role === UserRole.SECURITY && (
        <section>
          <div className="flex items-center gap-3 mb-8">
            <MapPin className="text-indigo-600" size={24} />
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">Gate Verification Queue</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {pendingRequests.filter(r => r.status === RequestStatus.APPROVED).map(req => (
              <div key={req.id} className="bg-white rounded-[3rem] p-10 border-4 border-indigo-100 shadow-2xl animate-in zoom-in-95 duration-500">
                <div className="flex justify-between items-start mb-8">
                  <div>
                    <h3 className="font-black text-3xl text-slate-900 uppercase tracking-tight italic">{req.studentName}</h3>
                    <p className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mt-2">{req.studentRegNo}</p>
                  </div>
                </div>
                <div className="bg-slate-50 p-6 rounded-3xl mb-8 space-y-4">
                   <div className="flex justify-between text-xs font-black text-slate-400 uppercase tracking-widest">
                     <span>Classroom</span>
                     <span className="text-indigo-600">{req.classroomName}</span>
                   </div>
                   <div className="flex justify-between text-xs font-black text-slate-400 uppercase tracking-widest border-t pt-4">
                     <span>Duration</span>
                     <span className="text-slate-900">{req.stayDuration}</span>
                   </div>
                </div>
                <button
                  onClick={() => handleAction(req.id, 'exit')}
                  className="w-full bg-indigo-600 text-white font-black py-6 rounded-[1.5rem] hover:bg-indigo-700 transition shadow-2xl shadow-indigo-200 uppercase tracking-[0.3em] text-sm active:scale-95 flex items-center justify-center gap-4"
                >
                  <ShieldCheck size={24} />
                  VERIFY GATE EXIT
                </button>
              </div>
            ))}
            {pendingRequests.filter(r => r.status === RequestStatus.APPROVED).length === 0 && (
              <div className="col-span-full py-28 bg-white rounded-[3rem] border-4 border-dashed border-slate-50 text-center">
                 <p className="text-slate-200 font-black uppercase text-3xl tracking-widest italic opacity-50">Zero Pending Exits</p>
              </div>
            )}
          </div>
        </section>
      )}

      <section className="bg-white rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
        <div className="p-10 border-b border-slate-50 flex flex-col md:flex-row md:items-center justify-between gap-8">
          <div className="flex items-center gap-4">
            <div className="bg-indigo-600 p-3 rounded-2xl text-white shadow-lg">
              <GraduationCap size={24} />
            </div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight italic">Audit Records</h2>
          </div>
          <div className="relative group w-full md:w-96">
            <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="Search registry..."
              className="w-full pl-14 pr-8 py-5 bg-slate-50 border-2 border-transparent rounded-2xl outline-none focus:bg-white focus:border-indigo-600 font-black text-sm transition-all shadow-inner"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[1000px]">
            <thead>
              <tr className="bg-slate-50/80 border-b">
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest">Identity / Group</th>
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest text-center">GPA</th>
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest text-center">History</th>
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest">Purpose</th>
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest text-center">Current Status</th>
                <th className="px-10 py-8 font-black text-slate-400 uppercase text-[10px] tracking-widest text-right">Registry Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredHistory.map(req => (
                <tr key={req.id} className="hover:bg-indigo-50/30 transition-all duration-300 group/row">
                  <td className="px-10 py-8">
                    <p className="font-black text-slate-800 uppercase tracking-tight text-lg leading-none">{req.studentName}</p>
                    <p className="text-[10px] text-indigo-500 font-black uppercase tracking-widest mt-2 italic">{req.classroomName}</p>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <span className="font-black text-slate-700 bg-slate-100 border border-slate-200 px-4 py-1.5 rounded-xl">{req.cgpa}</span>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <span className="font-black text-amber-700 bg-amber-50 border border-amber-100 px-4 py-1.5 rounded-xl text-[10px] uppercase tracking-widest">
                      {req.previousLeaveCount} Past Leaves
                    </span>
                  </td>
                  <td className="px-10 py-8 max-w-[250px]">
                    <p className="font-black text-slate-400 text-xs uppercase tracking-tight truncate leading-relaxed" title={req.reason}>
                      {req.reason}
                    </p>
                  </td>
                  <td className="px-10 py-8 text-center">
                    <span className={`inline-flex px-6 py-3 rounded-2xl text-[10px] font-black uppercase border tracking-[0.2em] min-w-[180px] justify-center items-center shadow-sm ${
                      req.status === RequestStatus.APPROVED ? 'bg-green-50 text-green-700 border-green-200' :
                      req.status === RequestStatus.REJECTED ? 'bg-red-50 text-red-700 border-red-200' :
                      req.status === RequestStatus.EXITED ? 'bg-indigo-600 text-white border-indigo-700 shadow-lg shadow-indigo-100' : 'bg-amber-50 text-amber-700 border-amber-200'
                    }`}>
                      {req.status === RequestStatus.EXITED ? 'EXIT VERIFIED' : req.status.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="px-10 py-8 font-black text-slate-300 text-[11px] uppercase text-right tracking-widest">
                    {new Date(req.createdAt).toLocaleDateString()}
                  </td>
                </tr>
              ))}
              {filteredHistory.length === 0 && (
                <tr>
                  <td colSpan={6} className="px-10 py-32 text-center text-slate-200 font-black uppercase text-2xl tracking-widest italic opacity-50">
                    Registry matching zero records
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default ApprovalDashboard;
