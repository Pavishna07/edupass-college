
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { db } from '../services/mockDb';
import { OutpassRequest, RequestStatus, UserRole, Gender, User, Classroom } from '../types';
import { Plus, Clock, CheckCircle2, XCircle, ChevronRight, FileText, History, Info, Hash } from 'lucide-react';

const StudentHome: React.FC = () => {
  const { user } = useAuth();
  const [requests, setRequests] = useState<OutpassRequest[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  
  const [reason, setReason] = useState('');
  const [duration, setDuration] = useState('');
  const [cgpa, setCgpa] = useState('');
  const [previousLeaves, setPreviousLeaves] = useState('');
  const [selectedClassId, setSelectedClassId] = useState('');
  const [selectedWarden, setSelectedWarden] = useState('');
  const [selectedDeputy, setSelectedDeputy] = useState('');

  const [availableWardens, setAvailableWardens] = useState<User[]>([]);
  const [availableDeputies, setAvailableDeputies] = useState<User[]>([]);
  const [availableClassrooms, setAvailableClassrooms] = useState<(Classroom & { advisorName: string })[]>([]);

  useEffect(() => {
    if (user) {
      const myReqs = db.getRequests().filter(r => r.studentId === user.uid);
      setRequests(myReqs.sort((a, b) => b.createdAt - a.createdAt));

      // Filter classrooms by department and join advisor names
      const deptClasses = db.getClassrooms().filter(c => c.department === user.department);
      const classesWithAdvisors = deptClasses.map(c => {
        const advisor = db.getUser(c.advisorId);
        return { ...c, advisorName: advisor?.displayName || 'Unknown Advisor' };
      });
      setAvailableClassrooms(classesWithAdvisors);

      // Pre-select student's own class if exists
      if (user.classroomId) setSelectedClassId(user.classroomId);

      // Filter wardens and deputies by gender
      const allWardens = db.getUsersByRole(UserRole.WARDEN);
      const allDeputies = db.getUsersByRole(UserRole.DEPUTY_WARDEN);

      // Strictly filtered by gender for both Warden and Deputy Warden
      setAvailableWardens(allWardens.filter(w => w.gender === user.gender));
      setAvailableDeputies(allDeputies.filter(d => d.gender === user.gender));
    }
  }, [user]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const classroom = availableClassrooms.find(c => c.id === selectedClassId);
    if (!classroom) {
      alert("Please select your classroom.");
      return;
    }

    const advisor = db.getUser(classroom.advisorId);
    if (!advisor) {
      alert("Advisor not found for this classroom. Please select another.");
      return;
    }

    if (!selectedWarden || !selectedDeputy) {
      alert("Please select both Warden and Deputy Warden.");
      return;
    }

    // Link student to this classroom and advisor if not already linked
    if (user.classroomId !== selectedClassId) {
      db.updateUser(user.uid, {
        classroomId: selectedClassId,
        advisorRef: classroom.advisorId,
        hodRef: advisor.hodRef
      });
    }

    const newReq: OutpassRequest = {
      id: `req-${Date.now()}`,
      studentId: user.uid,
      studentName: user.displayName,
      studentRegNo: user.registerNo || '',
      department: user.department!,
      classroomName: classroom.name,
      cgpa: cgpa,
      reason,
      stayDuration: duration,
      status: RequestStatus.PENDING,
      currentLevel: UserRole.ADVISOR,
      createdAt: Date.now(),
      wardenId: selectedWarden,
      deputyWardenId: selectedDeputy,
      previousLeaveCount: parseInt(previousLeaves) || 0,
      advisorId: classroom.advisorId,
      hodId: advisor.hodRef
    };

    db.addRequest(newReq);
    setRequests([newReq, ...requests]);
    setIsModalOpen(false);
    // Reset fields
    setReason('');
    setDuration('');
    setCgpa('');
    setPreviousLeaves('');
    setSelectedWarden('');
    setSelectedDeputy('');
  };

  const getStatusColor = (status: RequestStatus) => {
    switch (status) {
      case RequestStatus.APPROVED: return 'text-green-600 bg-green-50 border-green-200';
      case RequestStatus.REJECTED: return 'text-red-600 bg-red-50 border-red-200';
      case RequestStatus.EXITED: return 'text-blue-600 bg-blue-50 border-blue-200';
      default: return 'text-amber-600 bg-amber-50 border-amber-200';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight">My Outpasses</h1>
          <p className="text-slate-500 font-medium">View and request exit permits</p>
        </div>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center space-x-2 bg-indigo-600 text-white font-black px-6 py-3 rounded-xl shadow-lg hover:bg-indigo-700 transition active:scale-95"
        >
          <Plus size={20} />
          <span>New Request</span>
        </button>
      </div>

      <div className="space-y-4">
        {requests.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-2xl border-2 border-dashed border-slate-200">
            <FileText className="mx-auto text-slate-300 mb-4" size={64} />
            <p className="text-slate-400 font-bold text-xl">No outpass history yet</p>
            <p className="text-slate-400 font-medium">Apply for your first outpass to see it here</p>
          </div>
        ) : (
          requests.map(req => (
            <div key={req.id} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-4 transition hover:shadow-md">
              <div className="flex items-center space-x-4">
                <div className={`p-3 rounded-xl ${getStatusColor(req.status)} border`}>
                  {req.status === RequestStatus.APPROVED ? <CheckCircle2 size={24} /> : 
                   req.status === RequestStatus.REJECTED ? <XCircle size={24} /> : <Clock size={24} />}
                </div>
                <div>
                  <p className="text-lg font-black text-slate-800 leading-tight">{req.reason}</p>
                  <div className="flex items-center space-x-3 text-xs text-slate-500 font-bold uppercase mt-1">
                    <span className="bg-slate-100 px-2 py-0.5 rounded text-indigo-600">{req.classroomName}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                    <span>{req.stayDuration}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full"></span>
                    <span>Past: {req.previousLeaveCount}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="text-right">
                  <p className={`text-[10px] font-black uppercase tracking-wider ${getStatusColor(req.status)} px-3 py-1 rounded-full inline-block border border-current`}>
                    {req.status.replace('_', ' ')}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1 font-black uppercase">
                    Next: {req.currentLevel.replace('_', ' ')}
                  </p>
                </div>
                <ChevronRight className="text-slate-300" />
              </div>
            </div>
          ))
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-lg overflow-y-auto max-h-[90vh] animate-in zoom-in duration-300 border border-indigo-50">
            <div className="bg-indigo-600 p-8 text-white flex justify-between items-center sticky top-0 z-10 shadow-xl">
              <div>
                <h2 className="text-3xl font-black uppercase tracking-tight italic">Apply Outpass</h2>
                <p className="text-indigo-100 text-xs font-bold uppercase tracking-widest mt-1">Fill all fields accurately</p>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-white hover:bg-white/20 p-2 rounded-2xl transition active:scale-90">
                <XCircle size={32} />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-8 space-y-6">
              <div className="col-span-full">
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Select Your Separate Classroom</label>
                <select
                  required
                  className="w-full px-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                  value={selectedClassId}
                  onChange={e => setSelectedClassId(e.target.value)}
                >
                  <option value="">Choose your room ({user?.department})</option>
                  {availableClassrooms.map(c => (
                    <option key={c.id} value={c.id}>{c.name} (Advisor: {c.advisorName})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Current CGPA</label>
                  <input
                    required
                    type="number"
                    step="0.01"
                    max="10"
                    min="0"
                    className="w-full px-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                    placeholder="e.g. 8.5"
                    value={cgpa}
                    onChange={e => setCgpa(e.target.value)}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Stay Duration</label>
                  <input
                    required
                    className="w-full px-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                    placeholder="e.g. 3 Days"
                    value={duration}
                    onChange={e => setDuration(e.target.value)}
                  />
                </div>
              </div>

              <div className="col-span-full">
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Previous Leave Count</label>
                <div className="relative">
                  <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                  <input
                    required
                    type="number"
                    min="0"
                    className="w-full pl-12 pr-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                    placeholder="Enter number of times you left"
                    value={previousLeaves}
                    onChange={e => setPreviousLeaves(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Reason for Outpass</label>
                <textarea
                  required
                  rows={4}
                  className="w-full px-5 py-4 rounded-[1.5rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm resize-none"
                  placeholder="Provide a detailed reason..."
                  value={reason}
                  onChange={e => setReason(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Select Warden</label>
                  <select
                    required
                    className="w-full px-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                    value={selectedWarden}
                    onChange={e => setSelectedWarden(e.target.value)}
                  >
                    <option value="">Choose Warden</option>
                    {availableWardens.map(w => (
                      <option key={w.uid} value={w.uid}>{w.displayName} ({w.gender})</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-[0.2em]">Select Deputy Warden</label>
                  <select
                    required
                    className="w-full px-5 py-4 rounded-[1.25rem] border-2 border-slate-100 bg-slate-50 font-black text-slate-900 focus:bg-white focus:border-indigo-600 outline-none transition shadow-sm"
                    value={selectedDeputy}
                    onChange={e => setSelectedDeputy(e.target.value)}
                  >
                    <option value="">Choose Deputy</option>
                    {availableDeputies.map(d => (
                      <option key={d.uid} value={d.uid}>{d.displayName} ({d.gender})</option>
                    ))}
                  </select>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 text-white font-black py-5 rounded-[1.5rem] shadow-2xl shadow-indigo-200 hover:bg-indigo-700 transition transform active:scale-[0.98] text-lg uppercase tracking-[0.2em] mt-4"
              >
                Submit Application
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentHome;
