
import React, { useState, useEffect } from 'react';
import { useAuth } from '../App';
import { db } from '../services/mockDb';
import { User, UserRole, Classroom } from '../types';
// Fixed missing import: Added ShieldCheck to the lucide-react imports
import { Plus, Trash2, Users, DoorOpen, User as UserIcon, BookOpen, X, AlertCircle, UserMinus, ShieldCheck } from 'lucide-react';

const ClassroomManager: React.FC = () => {
  const { user } = useAuth();
  const [classrooms, setClassrooms] = useState<Classroom[]>([]);
  const [selectedClassroom, setSelectedClassroom] = useState<Classroom | null>(null);
  const [studentsInSelected, setStudentsInSelected] = useState<User[]>([]);
  const [advisorsInDept, setAdvisorsInDept] = useState<User[]>([]);
  const [newClassName, setNewClassName] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    if (!user) return;
    refreshData();
  }, [user, selectedClassroom?.id]);

  const refreshData = () => {
    if (!user) return;
    
    if (user.role === UserRole.ADVISOR) {
      const myClasses = db.getClassrooms().filter(c => c.advisorId === user.uid);
      setClassrooms(myClasses);
      
      if (selectedClassroom) {
        const updatedSelected = myClasses.find(c => c.id === selectedClassroom.id);
        if (updatedSelected) {
          setSelectedClassroom(updatedSelected);
          const stus = db.getUsersByRole(UserRole.STUDENT).filter(s => s.classroomId === updatedSelected.id);
          setStudentsInSelected(stus);
        } else {
          setSelectedClassroom(null);
        }
      }
    } else if (user.role === UserRole.HOD) {
      const advs = db.getUsersByRole(UserRole.ADVISOR).filter(a => a.department === user.department);
      setAdvisorsInDept(advs);
    }
  };

  const createClassroom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newClassName.trim()) return;
    
    const newCls: Classroom = {
      id: `cls-${Date.now()}`,
      name: newClassName.trim(),
      advisorId: user.uid,
      department: user.department!,
      studentIds: []
    };
    
    db.addClassroom(newCls);
    setNewClassName('');
    setIsCreating(false);
    refreshData();
  };

  const deleteClassroom = (clsId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const students = db.getUsersByRole(UserRole.STUDENT).filter(s => s.classroomId === clsId);
    const studentCount = students.length;
    
    const message = studentCount > 0 
      ? `This separate classroom contains ${studentCount} students. Deleting it will unassign all of them and they will need to select a new room. Proceed?`
      : 'Are you sure you want to delete this separate classroom group?';

    if (window.confirm(message)) {
      // Unlink students
      students.forEach(s => db.updateUser(s.uid, { 
        classroomId: '', 
        advisorRef: '', 
        hodRef: '' 
      }));
      
      // Remove classroom object
      const allCls = db.getClassrooms();
      const updatedCls = allCls.filter(c => c.id !== clsId);
      // Direct mutation of private state for mock simulation
      (db as any).data.classrooms = updatedCls;
      (db as any).save();
      
      refreshData();
    }
  };

  const selectClassroom = (cls: Classroom) => {
    setSelectedClassroom(cls);
    const stus = db.getUsersByRole(UserRole.STUDENT).filter(s => s.classroomId === cls.id);
    setStudentsInSelected(stus);
  };

  const removeStudentFromRoom = (studentUid: string) => {
    if (window.confirm('Remove this student from your separate group? They will need to re-join a classroom to submit outpasses.')) {
      db.updateUser(studentUid, { 
        classroomId: '', 
        advisorRef: '', 
        hodRef: '' 
      });
      refreshData();
    }
  };

  const removeAdvisorFromDept = (advisorUid: string) => {
    if (window.confirm('Are you sure you want to PERMANENTLY remove this advisor and all their associated data from the department?')) {
      db.deleteUser(advisorUid);
      refreshData();
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-4">
          <div className="bg-indigo-600 p-3 rounded-2xl text-white shadow-xl shadow-indigo-100">
            <DoorOpen size={32} />
          </div>
          <div>
            <h1 className="text-3xl font-extrabold text-slate-800 tracking-tight uppercase italic leading-none">
              {user?.role === UserRole.ADVISOR ? 'Group Manager' : 'Faculty Oversight'}
            </h1>
            <p className="text-indigo-600 font-black uppercase tracking-widest text-[10px] mt-2 italic">
              {user?.role === UserRole.ADVISOR ? 'MANAGE SEPARATE STUDENT CLUSTERS' : 'MANAGE ADVISORS IN YOUR DEPARTMENT'}
            </p>
          </div>
        </div>
        {user?.role === UserRole.ADVISOR && !selectedClassroom && (
          <button
            onClick={() => setIsCreating(true)}
            className="bg-indigo-600 text-white font-black px-6 py-4 rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition flex items-center gap-2 uppercase tracking-widest text-xs active:scale-95"
          >
            <Plus size={20} />
            Create Separate Room
          </button>
        )}
        {selectedClassroom && (
          <button
            onClick={() => setSelectedClassroom(null)}
            className="text-indigo-600 font-black hover:text-indigo-800 transition flex items-center gap-2 uppercase tracking-widest text-xs bg-indigo-50 px-5 py-3 rounded-xl border border-indigo-100 shadow-sm"
          >
            <X size={20} />
            Exit Group
          </button>
        )}
      </div>

      {user?.role === UserRole.ADVISOR && (
        <div className="space-y-6">
          {isCreating && (
            <div className="bg-white p-8 rounded-[2rem] shadow-2xl border-2 border-indigo-100 animate-in fade-in slide-in-from-top-4 duration-300">
              <h2 className="text-xl font-black text-slate-800 uppercase mb-4 flex items-center gap-2 italic">
                <Plus className="text-indigo-600" /> New Separate Cluster
              </h2>
              <form onSubmit={createClassroom} className="flex flex-col sm:flex-row gap-4">
                <input
                  autoFocus
                  type="text"
                  placeholder="e.g. 2nd Year ECE - Section A"
                  className="flex-grow px-6 py-5 rounded-[1.25rem] border-2 border-slate-100 outline-none focus:border-indigo-600 font-black text-lg shadow-sm bg-slate-50 focus:bg-white transition-all"
                  value={newClassName}
                  onChange={e => setNewClassName(e.target.value)}
                />
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => setIsCreating(false)}
                    className="px-8 py-5 font-black text-slate-500 hover:bg-slate-50 rounded-[1.25rem] transition uppercase tracking-widest text-[10px]"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="bg-indigo-600 text-white font-black px-12 py-5 rounded-[1.25rem] shadow-2xl shadow-indigo-100 hover:bg-indigo-700 transition uppercase tracking-widest text-[10px]"
                  >
                    Add Cluster
                  </button>
                </div>
              </form>
            </div>
          )}

          {!selectedClassroom ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {classrooms.length === 0 && !isCreating ? (
                <div className="col-span-full py-28 bg-white rounded-[3rem] border-2 border-dashed border-slate-200 text-center shadow-inner">
                  <BookOpen className="mx-auto text-slate-200 mb-8" size={84} />
                  <p className="text-slate-400 font-black text-2xl uppercase tracking-tight italic">No Separate Rooms Defined</p>
                  <p className="text-slate-400 font-bold mt-2 uppercase text-xs tracking-widest opacity-60">Create clusters to organize student applications</p>
                  <button
                    onClick={() => setIsCreating(true)}
                    className="mt-10 bg-indigo-50 text-indigo-600 font-black px-10 py-5 rounded-2xl hover:bg-indigo-100 transition uppercase tracking-widest text-xs border border-indigo-100 shadow-sm"
                  >
                    + Setup Your First Group
                  </button>
                </div>
              ) : (
                classrooms.map(cls => (
                  <div
                    key={cls.id}
                    onClick={() => selectClassroom(cls)}
                    className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 text-left hover:border-indigo-500 hover:shadow-2xl transition-all duration-500 group cursor-pointer relative overflow-hidden"
                  >
                    <div className="absolute top-0 right-0 w-40 h-40 bg-indigo-600 rounded-full -mr-20 -mt-20 group-hover:scale-125 transition-all duration-700 opacity-0 group-hover:opacity-10"></div>
                    
                    <div className="relative z-10">
                      <div className="bg-indigo-600 w-16 h-16 rounded-2xl flex items-center justify-center text-white mb-8 shadow-xl shadow-indigo-100 group-hover:rotate-12 transition-transform">
                        <Users size={32} />
                      </div>
                      <h3 className="text-2xl font-black text-slate-800 mb-1 leading-tight uppercase group-hover:text-indigo-600 transition-colors italic tracking-tight">{cls.name}</h3>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-8 italic">{cls.department} Branch Group</p>
                      
                      <div className="flex items-center justify-between border-t border-slate-50 pt-8">
                        <div className="flex items-center gap-2">
                          <Users size={16} className="text-indigo-400" />
                          <span className="text-[11px] font-black text-slate-700 uppercase tracking-widest">
                            {db.getUsersByRole(UserRole.STUDENT).filter(s => s.classroomId === cls.id).length} MEMBERS
                          </span>
                        </div>
                        <button
                          // Fixed: Changed deleteCluster to deleteClassroom
                          onClick={(e) => deleteClassroom(cls.id, e)}
                          className="p-3 text-slate-200 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all opacity-0 group-hover:opacity-100"
                          title="Delete Entire Group"
                        >
                          <Trash2 size={24} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          ) : (
            <section className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-500">
              <div className="p-10 bg-indigo-600 text-white flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
                <div className="flex items-center gap-6">
                  <div className="bg-white/20 p-5 rounded-[1.5rem] backdrop-blur-xl shadow-inner">
                    <Users size={40} />
                  </div>
                  <div>
                    <h2 className="text-4xl font-black uppercase tracking-tight leading-none italic">{selectedClassroom.name}</h2>
                    <p className="text-indigo-100 text-[10px] font-black uppercase tracking-[0.2em] mt-3 flex items-center gap-2">
                      <ShieldCheck size={14} className="text-white" /> VERIFIED MEMBER DIRECTORY
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-white/10 text-white border border-white/20 px-8 py-3.5 rounded-[1.25rem] text-[11px] font-black uppercase tracking-widest shadow-2xl backdrop-blur-md">
                    {studentsInSelected.length} TOTAL STUDENTS
                  </div>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b bg-slate-50/80">
                      <th className="px-12 py-8 font-black text-slate-400 uppercase text-[11px] tracking-widest">Student Profile</th>
                      <th className="px-12 py-8 font-black text-slate-400 uppercase text-[11px] tracking-widest">Registration ID</th>
                      <th className="px-12 py-8 font-black text-slate-400 uppercase text-[11px] tracking-widest text-right">Management</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {studentsInSelected.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="px-12 py-32 text-center">
                          <div className="bg-slate-50 w-28 h-28 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                            <UserIcon className="text-slate-200" size={56} />
                          </div>
                          <p className="text-slate-400 font-black text-2xl uppercase italic tracking-tight">Empty Registry</p>
                          <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-3 opacity-60 italic">Students must choose this cluster during signup or request process</p>
                        </td>
                      </tr>
                    ) : (
                      studentsInSelected.map(s => (
                        <tr key={s.uid} className="hover:bg-indigo-50/40 transition-all duration-300 group/row">
                          <td className="px-12 py-8">
                            <div className="flex items-center gap-6">
                              <div className="w-16 h-16 rounded-[1.25rem] bg-slate-100 border-2 border-slate-200 flex items-center justify-center text-slate-400 overflow-hidden shadow-sm group-hover/row:border-indigo-400 transition-all group-hover/row:scale-105">
                                {s.profilePhoto ? <img src={s.profilePhoto} className="w-full h-full object-cover" /> : <UserIcon size={28} />}
                              </div>
                              <div>
                                <span className="font-black text-slate-800 text-xl uppercase tracking-tight block leading-tight mb-1 group-hover/row:text-indigo-600 transition-colors">{s.displayName}</span>
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest italic">{s.email}</span>
                              </div>
                            </div>
                          </td>
                          <td className="px-12 py-8">
                            <span className="font-black text-indigo-700 bg-white border-2 border-indigo-50 px-5 py-2.5 rounded-[1rem] text-sm shadow-sm tracking-[0.1em]">{s.registerNo}</span>
                          </td>
                          <td className="px-12 py-8 text-right">
                            <button
                              onClick={() => removeStudentFromRoom(s.uid)}
                              className="text-red-400 hover:text-red-600 p-5 rounded-[1.25rem] hover:bg-red-50 transition-all active:scale-90 flex items-center gap-3 ml-auto group/btn border border-transparent hover:border-red-100 shadow-sm hover:shadow-md"
                            >
                              <span className="text-[10px] font-black uppercase opacity-0 group-hover/btn:opacity-100 transition-all tracking-widest">Remove Student</span>
                              <UserMinus size={24} />
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>
      )}

      {user?.role === UserRole.HOD && (
        <section className="bg-white rounded-[3rem] shadow-sm border border-slate-100 overflow-hidden">
          <div className="p-12 bg-slate-50 border-b flex justify-between items-center">
            <div className="flex items-center gap-6">
              <div className="bg-indigo-600 p-4 rounded-[1.5rem] text-white shadow-xl shadow-indigo-50">
                <Users size={28} />
              </div>
              <div>
                <h2 className="text-3xl font-black text-slate-800 uppercase tracking-tight leading-none italic">Department Hierarchy</h2>
                <p className="text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mt-3">{user.department} FACULTY OVERSIGHT CONTROL</p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 p-12">
            {advisorsInDept.map(adv => (
              <div key={adv.uid} className="p-10 border-2 rounded-[2.5rem] flex flex-col justify-between hover:shadow-2xl transition-all duration-500 bg-white border-slate-100 hover:border-indigo-300 group">
                <div>
                  <div className="flex items-start justify-between mb-10">
                    <div className="flex items-center space-x-6">
                      {adv.profilePhoto ? (
                        <img src={adv.profilePhoto} className="w-24 h-24 rounded-[2rem] border-4 border-white object-cover shadow-2xl shadow-indigo-100 group-hover:scale-105 transition-transform" />
                      ) : (
                        <div className="w-24 h-24 rounded-[2rem] bg-indigo-50 flex items-center justify-center text-indigo-200 border-2 border-indigo-100">
                          <UserIcon size={48} />
                        </div>
                      )}
                      <div>
                        <p className="font-black text-2xl text-slate-800 uppercase tracking-tight leading-tight group-hover:text-indigo-600 transition-colors italic">{adv.displayName}</p>
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mt-2 italic">{adv.email}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-4 mb-10">
                    <div className="flex items-center gap-4 text-slate-600 font-black text-[11px] uppercase bg-slate-50/80 p-5 rounded-[1.25rem] border border-slate-100 group-hover:bg-indigo-50/30 transition-colors">
                      <BookOpen size={20} className="text-indigo-500" />
                      <span>{db.getClassrooms().filter(c => c.advisorId === adv.uid).length} DEFINED GROUPS</span>
                    </div>
                  </div>
                </div>
                
                <div className="pt-8 border-t border-slate-50 flex justify-between items-center">
                  <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-5 py-2.5 rounded-xl uppercase tracking-widest border border-indigo-100 shadow-sm italic">Verified Faculty</span>
                  <button
                    onClick={() => removeAdvisorFromDept(adv.uid)}
                    className="text-red-300 hover:bg-red-50 p-4 rounded-2xl transition-all hover:text-red-600 active:scale-90 border border-transparent hover:border-red-100"
                    title="Terminate Faculty Access"
                  >
                    <Trash2 size={28} />
                  </button>
                </div>
              </div>
            ))}
            {advisorsInDept.length === 0 && (
              <div className="col-span-full py-32 text-center opacity-60">
                <div className="bg-slate-50 w-32 h-32 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                  <UserIcon className="text-slate-200" size={64} />
                </div>
                <p className="text-slate-400 font-black uppercase text-2xl italic tracking-tight">Zero Faculty Registered</p>
                <p className="text-slate-400 font-black uppercase text-[10px] tracking-widest mt-3">Advisors will appear here after they join the department registry</p>
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};

export default ClassroomManager;
