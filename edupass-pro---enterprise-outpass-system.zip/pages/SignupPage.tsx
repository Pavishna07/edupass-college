
import React, { useState, useRef, useEffect } from 'react';
import { db } from '../services/mockDb';
import { UserRole, Gender, DEPARTMENTS, Department, User, Classroom } from '../types';
import { useNavigate } from 'react-router-dom';
import { Camera, RefreshCw, Eye, EyeOff } from 'lucide-react';

const SignupPage: React.FC = () => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    displayName: '',
    password: '',
    role: UserRole.STUDENT,
    gender: Gender.MALE,
    department: 'CSE' as Department,
    registerNo: '',
    profilePhoto: '',
    advisorRef: '',
    hodRef: '',
    classroomId: '',
  });

  const [availableHods, setAvailableHods] = useState<User[]>([]);

  useEffect(() => {
    if (step === 2 && formData.role !== UserRole.STUDENT) {
      startCamera();
    }
  }, [step, formData.role]);

  useEffect(() => {
    // Filter HODs based on department
    const hods = db.getUsersByRole(UserRole.HOD).filter(u => u.department === formData.department);
    setAvailableHods(hods);
  }, [formData.department]);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      console.error("Camera access denied", err);
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const ctx = canvasRef.current.getContext('2d');
      if (ctx) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        ctx.drawImage(videoRef.current, 0, 0);
        const data = canvasRef.current.toDataURL('image/png');
        setFormData({ ...formData, profilePhoto: data });
        const stream = videoRef.current.srcObject as MediaStream;
        stream.getTracks().forEach(t => t.stop());
      }
    }
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();
    
    // For students, the register number is their password
    const finalPassword = formData.role === UserRole.STUDENT ? formData.registerNo : formData.password;
    
    if (!finalPassword) {
      alert("Please provide a password.");
      return;
    }

    const newUser: User = {
      uid: `user-${Date.now()}`,
      ...formData,
      password: finalPassword
    };
    
    db.addUser(newUser);
    alert('Account created successfully! Please login.');
    navigate('/login');
  };

  const isAuthority = formData.role !== UserRole.STUDENT;

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
        <div className="bg-indigo-600 p-8 text-white relative overflow-hidden">
          <div className="relative z-10">
            <h1 className="text-4xl font-black uppercase tracking-tight italic">EduPass</h1>
            <p className="mt-2 text-indigo-100 font-bold uppercase tracking-widest text-xs">Authority & Student Registration</p>
          </div>
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -mr-16 -mt-16 blur-2xl"></div>
        </div>

        <form onSubmit={handleSignup} className="p-8 space-y-6">
          {step === 1 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="col-span-full">
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Full Name</label>
                <input
                  required
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-lg text-slate-900 focus:border-indigo-600 outline-none transition uppercase"
                  value={formData.displayName}
                  onChange={e => setFormData({ ...formData, displayName: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Email Address</label>
                <input
                  required type="email"
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-lg text-slate-900 focus:border-indigo-600 outline-none transition"
                  value={formData.email}
                  onChange={e => setFormData({ ...formData, email: e.target.value })}
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">System Role</label>
                <select
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-slate-900 focus:border-indigo-600 outline-none transition"
                  value={formData.role}
                  onChange={e => setFormData({ ...formData, role: e.target.value as UserRole })}
                >
                  {Object.values(UserRole).filter(r => r !== UserRole.ADMIN).map(role => (
                    <option key={role} value={role}>{role.replace('_', ' ').toUpperCase()}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Gender</label>
                <select
                  className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-slate-900 focus:border-indigo-600 outline-none transition"
                  value={formData.gender}
                  onChange={e => setFormData({ ...formData, gender: e.target.value as Gender })}
                >
                  <option value={Gender.MALE}>Male</option>
                  <option value={Gender.FEMALE}>Female</option>
                </select>
              </div>

              {(formData.role === UserRole.STUDENT || formData.role === UserRole.ADVISOR || formData.role === UserRole.HOD) && (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Department</label>
                  <select
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-slate-900 focus:border-indigo-600 outline-none transition"
                    value={formData.department}
                    onChange={e => setFormData({ ...formData, department: e.target.value as Department })}
                  >
                    {DEPARTMENTS.map(dept => <option key={dept} value={dept}>{dept}</option>)}
                  </select>
                </div>
              )}

              {/* Password for Authority roles */}
              {isAuthority && (
                <div className="relative">
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Account Password</label>
                  <div className="relative">
                    <input
                      required
                      type={showPassword ? 'text' : 'password'}
                      className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-lg text-slate-900 focus:border-indigo-600 outline-none transition"
                      value={formData.password}
                      onChange={e => setFormData({ ...formData, password: e.target.value })}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-indigo-600 transition"
                    >
                      {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                    </button>
                  </div>
                </div>
              )}

              {formData.role === UserRole.STUDENT && (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Register Number</label>
                  <input
                    required
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-lg text-slate-900 focus:border-indigo-600 outline-none transition"
                    placeholder="e.g. 21CS101"
                    value={formData.registerNo}
                    onChange={e => setFormData({ ...formData, registerNo: e.target.value })}
                  />
                  <p className="text-[9px] font-bold text-indigo-500 mt-1 italic uppercase">* Your Register No will be your password.</p>
                </div>
              )}

              {formData.role === UserRole.ADVISOR && (
                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-2 uppercase tracking-widest">Assign HOD</label>
                  <select
                    required
                    className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 font-black text-slate-900 focus:border-indigo-600 outline-none transition"
                    value={formData.hodRef}
                    onChange={e => setFormData({ ...formData, hodRef: e.target.value })}
                  >
                    <option value="">Choose HOD ({formData.department})</option>
                    {availableHods.map(h => <option key={h.uid} value={h.uid}>{h.displayName}</option>)}
                  </select>
                </div>
              )}
            </div>
          )}

          {step === 2 && isAuthority && (
            <div className="flex flex-col items-center space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-300">
              <div className="text-center">
                <h2 className="text-2xl font-black text-slate-900 uppercase">Identity Verification</h2>
                <p className="text-slate-500 font-bold text-sm uppercase tracking-tighter mt-1">Capture a clear face photo for authority validation</p>
              </div>
              
              <div className="relative w-full max-w-md aspect-video bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border-4 border-indigo-100 group">
                {!formData.profilePhoto ? (
                  <>
                    <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover scale-x-[-1]" />
                    <div className="absolute inset-0 border-2 border-dashed border-white/20 pointer-events-none rounded-2xl m-8"></div>
                    <button
                      type="button"
                      onClick={capturePhoto}
                      className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white text-indigo-600 p-5 rounded-2xl shadow-2xl hover:bg-slate-50 transition active:scale-90 group-hover:scale-110"
                    >
                      <Camera size={32} />
                    </button>
                  </>
                ) : (
                  <div className="relative w-full h-full">
                    <img src={formData.profilePhoto} className="w-full h-full object-cover scale-x-[-1]" alt="Captured" />
                    <div className="absolute inset-0 bg-indigo-600/10"></div>
                    <button
                      type="button"
                      onClick={() => { setFormData({...formData, profilePhoto: ''}); startCamera(); }}
                      className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white text-indigo-600 p-4 rounded-2xl shadow-2xl flex items-center gap-2 font-black uppercase tracking-widest text-xs"
                    >
                      <RefreshCw size={18} /> Retake Photo
                    </button>
                  </div>
                )}
              </div>
              <canvas ref={canvasRef} className="hidden" />
              <div className="flex items-center gap-3 text-amber-600 bg-amber-50 px-4 py-2 rounded-xl border border-amber-100">
                <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
                <p className="text-[10px] font-black uppercase tracking-widest">Live validation active</p>
              </div>
            </div>
          )}

          <div className="flex justify-between pt-8 border-t border-slate-100">
            {step === 2 && (
              <button
                type="button"
                onClick={() => setStep(1)}
                className="text-slate-400 font-black uppercase tracking-widest text-xs hover:text-slate-600 transition p-2"
              >
                Go Back
              </button>
            )}
            
            <button
              type="button"
              onClick={() => {
                if (step === 1 && isAuthority) setStep(2);
                else handleSignup(new Event('submit') as any);
              }}
              className="ml-auto bg-indigo-600 text-white font-black px-12 py-4 rounded-2xl shadow-xl shadow-indigo-100 hover:bg-indigo-700 transition transform active:scale-95 uppercase tracking-widest"
              disabled={step === 2 && isAuthority && !formData.profilePhoto}
            >
              {step === 1 && isAuthority ? 'Verify Identity' : 'Register Account'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignupPage;
