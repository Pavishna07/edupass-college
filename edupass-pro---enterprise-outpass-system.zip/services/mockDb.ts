
import { User, OutpassRequest, Classroom, UserRole, Notification } from '../types';

class MockDB {
  private static STORAGE_KEY = 'edupass_data';

  private data: {
    users: User[];
    requests: OutpassRequest[];
    classrooms: Classroom[];
    notifications: Notification[];
  } = {
    users: [],
    requests: [],
    classrooms: [],
    notifications: []
  };

  constructor() {
    this.load();
  }

  private load() {
    const stored = localStorage.getItem(MockDB.STORAGE_KEY);
    if (stored) {
      this.data = JSON.parse(stored);
    } else {
      // Seed some initial data if empty
      this.data.users = [
        {
          uid: 'admin-1',
          email: 'admin@college.edu',
          displayName: 'System Admin',
          role: UserRole.ADMIN,
          gender: 'Male' as any
        }
      ];
      this.data.notifications = [];
      this.save();
    }
  }

  private save() {
    localStorage.setItem(MockDB.STORAGE_KEY, JSON.stringify(this.data));
  }

  getUsersByRole(role: UserRole) {
    return this.data.users.filter(u => u.role === role);
  }

  getUser(uid: string) {
    return this.data.users.find(u => u.uid === uid);
  }

  addUser(user: User) {
    this.data.users.push(user);
    this.save();
  }

  updateUser(uid: string, updates: Partial<User>) {
    const idx = this.data.users.findIndex(u => u.uid === uid);
    if (idx !== -1) {
      this.data.users[idx] = { ...this.data.users[idx], ...updates };
      this.save();
    }
  }

  deleteUser(uid: string) {
    this.data.users = this.data.users.filter(u => u.uid !== uid);
    this.save();
  }

  getRequests() {
    return this.data.requests;
  }

  addRequest(req: OutpassRequest) {
    this.data.requests.push(req);
    this.save();
  }

  updateRequest(id: string, updates: Partial<OutpassRequest>) {
    const idx = this.data.requests.findIndex(r => r.id === id);
    if (idx !== -1) {
      this.data.requests[idx] = { ...this.data.requests[idx], ...updates };
      this.save();
    }
  }

  addClassroom(cls: Classroom) {
    this.data.classrooms.push(cls);
    this.save();
  }

  getClassrooms() {
    return this.data.classrooms;
  }

  updateClassroom(id: string, updates: Partial<Classroom>) {
    const idx = this.data.classrooms.findIndex(c => c.id === id);
    if (idx !== -1) {
      this.data.classrooms[idx] = { ...this.data.classrooms[idx], ...updates };
      this.save();
    }
  }

  // Notifications
  addNotification(notif: Notification) {
    if (!this.data.notifications) this.data.notifications = [];
    this.data.notifications.unshift(notif);
    this.save();
  }

  getNotifications(userId: string) {
    if (!this.data.notifications) return [];
    return this.data.notifications.filter(n => n.userId === userId);
  }

  markNotificationRead(id: string) {
    const idx = this.data.notifications.findIndex(n => n.id === id);
    if (idx !== -1) {
      this.data.notifications[idx].read = true;
      this.save();
    }
  }
}

export const db = new MockDB();
